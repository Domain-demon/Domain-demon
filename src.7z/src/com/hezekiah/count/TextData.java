package com.hezekiah.count;

public class TextData {

//    for(int j = 0;j< 4;j++){
//        switch (j) {
//            case 1:
//                int sum1 = 0;
//                for (int i = 0; i < basicattr.length; i++) {
//                    basicattr[sum1] = Integer.parseInt(jTextFields_1[sum1].getText().replaceAll("[^\\d]", ""));
//                    sum1++;
//                }
//                break;
//            case 2:
//                int sum2 = 0;
//                for (int i = 0; i < advattr.length; i++) {
//                    advattr[sum2] = Integer.parseInt(jTextFields_2[sum2++].getText().replaceAll("[^\\d]", ""));
//                    sum2++;
//                }
//                break;
//            case 3:
//                int sum3 = 0;
//                for (int i = 0; i < addattr.length; i++) {
//                    addattr[sum3] = Integer.parseInt(jTextFields_3[sum3++].getText().replaceAll("[^\\d]", ""));
//                    sum3++;
//                }
//                break;
//            case 4:
//                int sum4 = 0;
//                for (int i = 0; i < enattr.length; i++) {
//                    enattr[sum4] = Integer.parseInt(jTextFields_4[sum4++].getText().replaceAll("[^\\d]", ""));
//                    sum4++;
//                }
//                break;
//            default:
//                break;
//        }
//    }









}
