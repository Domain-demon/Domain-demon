package com.hezekiah.function;

import java.awt.*;

public class TextColor extends Color {
    public TextColor(int r, int g, int b) {
        super(r, g, b);
    }

//    public static Color TextColor1 = new Color(50,150,200);
//    public static Color TextColor2 = new Color(120,180,240);

    public static Color TextColor1 = new Color(214,214,214);
    public static Color TextColor2 = new Color(238,238,238);
    public static Color TextColor3 = new Color(240,240,240);
    public static Color TextColor4 = new Color(119,119,119);
}
