package com.hezekiah.function;

import javax.swing.*;

public class TextModule {
    public static JPanel[] textPanels(int c){
        return new JPanel[c];
    }

    public static JTextField[] text2Fields(int c){
        return new JTextField[c];
    }
}
